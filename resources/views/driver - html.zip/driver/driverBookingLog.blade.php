<!-- 
/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		driver_dashboard
 *	@date 		0
 *	@title 		Falah
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/
 -->
 <!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" >
	<head>
		<meta http-equiv="content-type" content="text/html" charset="utf-8" />
		<title>driver_dashboard</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="" >
		<link rel="StyleSheet" href="{{ asset('css/driver/driver_dashboard.css') }}" />
		<script src="https://secure.exportkit.com/cdn/js/ek_googlefonts.js"></script>
		<!-- Add your custom HEAD content here -->

	</head>
	<body>
		<div id="content-container" >


			<div id="page_booking_log_ek2"  >
				<div id="_bg__booking_log_ek3"  ></div>
				<div id="rectangle_1_ek2"  ></div>
				<div id="gocar" >
					GoCar
				</div>

				<div id="group_1"  >
					<div id="rectangle_2_ek1"  ></div>
					<div id="log_out_ek1" >
						Log Out
					</div>

				</div>
				<div id="booking_log_ek4" >
					Booking Log
				</div>
				<div id="customer_name" >
					Customer Name
				</div>
				<div id="_11_08_2020" >
					11/08/2020
				</div>
				<div id="_08_59am" >
					08:59AM
				</div>
				<img src="{{ asset('img/skins/line_1.png') }}" id="line_1" />
				<div id="gocar___driver_ek2" >
					GoCar | Driver
				</div>

				<div id="group_9_ek5"  >
					<div id="rectangle_2_ek2"  ></div>
					<div id="log_out_ek2" >
						Log Out
					</div>

				</div>
				<div id="ump_gambang_pahang" >
					UMP Gambang Pahang
				</div>
				<div id="ecm_mall" >
					ECM Mall
				</div>
				<img src="{{ asset('img/skins/drop_point_3.png') }}" id="drop_point_3" />
				<img src="{{ asset('img/skins/pickup_point_3.png') }}" id="pickup_point_3" />
				<div id="__" >
					-
				</div>
				<img src="{{ asset('img/skins/calendar_1.png') }}" id="calendar_1" />
				<img src="{{ asset('img/skins/clock_1.png') }}" id="clock_1" />
				<div id="customer_name_ek1" >
					Customer Name
				</div>
				<div id="_11_08_2020_ek1" >
					11/08/2020
				</div>
				<div id="_08_59am_ek1" >
					08:59AM
				</div>
				<img src="{{ asset('img/skins/line_4.png') }}" id="line_4" />
				<div id="ump_gambang_pahang_ek1" >
					UMP Gambang Pahang
				</div>
				<div id="ecm_mall_ek1" >
					ECM Mall
				</div>
				<img src="{{ asset('img/skins/drop_point_6.png') }}" id="drop_point_6" />
				<img src="{{ asset('img/skins/pickup_point_6.png') }}" id="pickup_point_6" />
				<div id="___ek1" >
					-
				</div>
				<img src="{{ asset('img/skins/calendar_4.png') }}" id="calendar_4" />
				<img src="{{ asset('img/skins/clock_4.png') }}" id="clock_4" />
				<div id="customer_name_ek2" >
					Customer Name
				</div>
				<div id="_11_08_2020_ek2" >
					11/08/2020
				</div>
				<div id="_08_59am_ek2" >
					08:59AM
				</div>
				<img src="{{ asset('img/skins/line_2.png') }}" id="line_2" />
				<div id="ump_gambang_pahang_ek2" >
					UMP Gambang Pahang
				</div>
				<div id="ecm_mall_ek2" >
					ECM Mall
				</div>
				<img src="{{ asset('img/skins/drop_point_4.png') }}" id="drop_point_4" />
				<img src="{{ asset('img/skins/pickup_point_4.png') }}" id="pickup_point_4" />
				<div id="___ek2" >
					-
				</div>
				<img src="{{ asset('img/skins/calendar_2.png') }}" id="calendar_2" />
				<img src="{{ asset('img/skins/clock_2.png') }}" id="clock_2" />
				<div id="customer_name_ek3" >
					Customer Name
				</div>
				<div id="_11_08_2020_ek3" >
					11/08/2020
				</div>
				<div id="_08_59am_ek3" >
					08:59AM
				</div>
				<img src="{{ asset('img/skins/line_3.png') }}" id="line_3" />
				<div id="ump_gambang_pahang_ek3" >
					UMP Gambang Pahang
				</div>
				<div id="ecm_mall_ek3" >
					ECM Mall
				</div>
				<img src="{{ asset('img/skins/drop_point_5.png') }}" id="drop_point_5" />
				<img src="{{ asset('img/skins/pickup_point_5.png') }}" id="pickup_point_5" />
				<div id="___ek3" >
					-
				</div>
				<img src="{{ asset('img/skins/calendar_3.png') }}" id="calendar_3" />
				<img src="{{ asset('img/skins/clock_3.png') }}" id="clock_3" />
			</div>
		</div>
	</body>
</html>