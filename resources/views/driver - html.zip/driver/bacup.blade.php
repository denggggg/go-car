<!-- 
/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		driver_dashboard
 *	@date 		0
 *	@title 		Falah
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/
 -->
 <!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" >
	<head>
		<meta http-equiv="content-type" content="text/html" charset="utf-8" />
		<title>driver_dashboard</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="" >
    <link rel="StyleSheet" href="{{ asset('css/driver/driver_dashboard.css') }}" />
		<script src="https://secure.exportkit.com/cdn/js/ek_googlefonts.js"></script>
		<!-- Add your custom HEAD content here -->

	</head>
	<body>
		<div id="content-container" >


			<div id="page_driver_profile_ek1"  >
				<div id="_bg__driver_profile_ek2"  ></div>
				<div id="rectangle_1_ek3"  ></div>
				<div id="gocar___driver_ek3" >
					GoCar | Driver
				</div>

				<div id="group_1_ek1"  >
					<div id="rectangle_2_ek3"  ></div>
					<div id="log_out_ek3" >
						Log Out
					</div>

				</div>
				<div id="my_profile" >
					My Profile
				</div>

				<div id="group_12"  >
					<div id="rectangle_17_ek1"  ></div>
					<div id="rectangle_18_ek1"  ></div>
					<div id="upload___" >
						Upload...
					</div>
					<img src="{{ asset('img/skins/ellipse_3.png') }}" id="ellipse_3"/>

				</div>
				<img src="{{ asset('img/skins/rectangle_21.png') }}" id="rectangle_21"/>
				<!--img src="{{ asset('img/skins/rectangle_24.png') }}" id="rectangle_24"/>
				<img src="{{ asset('img/skins/rectangle_26.png') }}" id="rectangle_26"/-->
				<div id="_09_10_2023_ek1" >
					<input type="texbox" name="license" placeholder="09/10/202">
				</div>
				<div id="universiti_malaysia_pahang__26600_pekan__pahang_ek1" >
					<input type="texbox" name="address" placeholder="Universiti Malaysia Pahang, 26600 Pekan, Pahang">
				</div>
				
				<!--img src="{{ asset('img/skins/rectangle_23.png') }}" id="rectangle_23" /-->
				<div id="_0196448184_ek1" >
					<input type="textbox" name="phone" placeholder="0196448184">
				</div>
				<!--img src="{{ asset('img/skins/rectangle_22.png') }}" id="rectangle_22" />
				<img src="{{ asset('img/skins/rectangle_25.png') }}" id="rectangle_25" /-->
				<div id="alif_masdo_gmail_com_ek1" >
				<input type="email" name="textbox" placeholder=" Alif_Masdo@gmail.com">
				</div>
				<div id="masdo2020_ek1" >
					<input type="password" name="password" placeholder="Masdo2020">
				</div>
				<div id="alif_iskandar_bin_azura_ek1" >
					<input type="textbox" name="name" placeholder="Alif Iskandar bin Azura">
				</div>
				<div id="phone_number__ek1" >
					Phone Number:
				</div>
				<div id="name_" >
					Name:
				</div>
				<div id="e_mail_" >
					E-mail:
				</div>
				<div id="password__ek1" >
					Password:
				</div>
				<div id="license_expiry_date_" >
					License expiry date: 
				</div>
				<div id="address_" >
					Address:
				</div>

				<div id="group_14"  >
					<div id="group_8_ek3"  >
						<div id="group_11_ek1"  >
							<div id="rectangle_11_ek1"  ></div><input type="button" id="but_update" value="Update Profile">
							<!--div id="update_profile" >
								
							</div-->
						</div>
					</div>
				</div>
				<div id="group_13"  >
					<div id="group_11_ek2"  >
						<div id="rectangle_11_ek2"  ></div>
						<div id="cancel" >
							Cancel
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>